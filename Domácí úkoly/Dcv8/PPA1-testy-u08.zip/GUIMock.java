import java.util.Hashtable;
import ppa1.GUI;

/**
 * Mockovaci trida pro GUI.
 * Umoznuje:
 * - testovat volani metody zapis
 * @author pvanecek
 *
 */
public class GUIMock extends GUI {

	/**
	 * Provedena volani
	 */
	public Hashtable<Integer, Character> zapisList = new Hashtable<Integer,Character>();
	
	/**
	 * Konstruktor 
	 */
	public GUIMock() {
		super(1,1,null);
	}
			
	private Integer xy2int(int x, int y) {
		return x + (y<<16);
	}
	
	/**
	 * Metoda zapis. Zapise volani do HashTable.
	 */
	@Override
	public void zapis(int x, int y, char znak) {
		zapisList.put(xy2int(x,y), znak);
	}	
	
	public char zapisCalls(int x, int y) {
		Integer xy = xy2int(x,y);
		if(zapisList.containsKey(xy)) {
			char result = zapisList.get(xy);
			zapisList.remove(xy);
			return result; 
		} else {
			return 0;
		}		
	}
	
	@Override
	public void smaz() {
		zapisList.clear();
	}
}
