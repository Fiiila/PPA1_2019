import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ppa1.GUI;
import ppa1.Smer;

/**
 * Test tridy GUI
 * @author pvanecek
 *
 */
public class GUITest {

	/**
	 * Test metody nacti akci
	 * - nacita jednotlive smery + chybne cislo
	 */
	@Test
	public void nactiAkci() {
		String input = String.format(Locale.US,"2\n4\n6\n8\n0\n");

		Scanner scanner = new Scanner(new ByteArrayInputStream(input.getBytes()));
		GUI gui = new GUI(5,5,scanner);
		
		assertTrue("Nacteni akce vraci jiny smer", gui.nactiAkci()==Smer.JIH);
		assertTrue("Nacteni akce vraci jiny smer", gui.nactiAkci()==Smer.ZAPAD);
		assertTrue("Nacteni akce vraci jiny smer", gui.nactiAkci()==Smer.VYCHOD);
		assertTrue("Nacteni akce vraci jiny smer", gui.nactiAkci()==Smer.SEVER);
		assertNull("Pro neplatnou klavesu vraci GUI smer", gui.nactiAkci());		
	}
	
	/**
	 * Test, zda se spravne vymaze a nasledne vykresli platno
	 */
	@Test
	public void smaz_vykresli() {
		GUI gui = new GUI(2,3,null);
		gui.smaz();
		gui.vykresli();
		
		Pattern pattern = Pattern.compile("[\\ ]{2}\\|[\\ ]{2}\\|[\\ ]{2}\\|?");
		Matcher matcher = pattern.matcher(redir_out.toString().replaceAll("(\\r\\n|\\n)", "|"));
		assertTrue("GUI vykreslilo spatny pocet radek ci sloupcu nebo nevycistilo spravne platno", matcher.find());
	}
	
	
	/**
	 * Test, zda se spravne zapise a nasledne vykresli platno
	 */
	@Test
	public void zapis_vykresli() {
		GUI gui = new GUI(3,2,null);
		gui.zapis(0, 0, '1');
		gui.zapis(1, 0, '2');
		gui.zapis(2, 0, '3');
		gui.zapis(0, 1, '4');
		gui.zapis(1, 1, '5');
		gui.zapis(2, 1, '6');
		gui.vykresli();
		
		Pattern pattern = Pattern.compile("123\\|456\\|?");
		Matcher matcher = pattern.matcher(redir_out.toString().replaceAll("(\\r\\n|\\n)", "|"));

		assertTrue("GUI zapsalo spatne znaky nebo je spatne vykreslilo", matcher.find());		
	}
		
	private final ByteArrayOutputStream redir_out = new ByteArrayOutputStream();
	private PrintStream save_out;

	/**
	 * Presmerovani stdout do byte streamu
	 */
	@Before
	public void setRedirect() {
		save_out = System.out;
		System.setOut(new PrintStream(redir_out));
	}

	/**
	 * Obnoveni stdout
	 */
	@After
	public void resetRedirect() {
		System.setOut(save_out);
	}


}
