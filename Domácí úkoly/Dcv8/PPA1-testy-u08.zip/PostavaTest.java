import static org.junit.Assert.*;

import org.junit.Test;

import ppa1.Postava;
import ppa1.Smer;
import ppa1.Svet;

/**
 * Test tridy Postava
 * @author pvanecek
 *
 */
public class PostavaTest {

	/**
	 * Testuje metodu vykresli a konstruktor.
	 */
	@Test
	public void vykresli() {
		GUIMock gui = new GUIMock();
		Postava p = new Postava(new Svet(1, 1, new char[] {' '}), 10,20,30,40);
		p.vykresli(gui);
		
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(10,20)=='@');
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(30, 40)== '^');
		assertTrue("Postava neco mockrat vykresluje", gui.zapisList.size()==0);
	}
	
	/**
	 * Testuje metodu jdi.
	 * - test pohybu na prazdne uzemi
	 * - test pohybu na obsazene uzemi
	 * - test pohybu mimo mapu 
	 */
	@Test
	public void jdi() {
		SvetMock svet = new SvetMock();
		GUIMock gui = new GUIMock();
		Postava p = new Postava(svet, 10,100,0,0);
		
		// pohyb na prazdne uzemi
		svet.uzemiReturn=' ';
		assertTrue("Postava se nechce presunout na prazdne misto", p.jdi(Smer.SEVER));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(10, 99)=='@');

		assertTrue("Postava se nechce presunout na prazdne misto", p.jdi(Smer.VYCHOD));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(11, 99)=='@');

		assertTrue("Postava se nechce presunout na prazdne misto", p.jdi(Smer.JIH));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(11, 100)=='@');

		assertTrue("Postava se nechce presunout na prazdne misto", p.jdi(Smer.ZAPAD));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(10, 100)=='@');

		// pohyb na obsazene uzemi
		gui.zapisList.clear();
		svet.uzemiReturn='#';
		assertFalse("Postava se chce presunout na obsazene misto", p.jdi(Smer.SEVER));		
		assertFalse("Postava se chce presunout na obsazene misto", p.jdi(Smer.VYCHOD));
		assertFalse("Postava se chce presunout na obsazene misto", p.jdi(Smer.JIH));
		assertFalse("Postava se chce presunout na obsazene misto", p.jdi(Smer.ZAPAD));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(10, 100)=='@');

		// pohyb mimo mapu
		gui.zapisList.clear();
		svet.uzemiReturn=0;
		assertFalse("Postava se chce presunout mimo mapu", p.jdi(Smer.SEVER));
		assertFalse("Postava se chce presunout mimo mapu", p.jdi(Smer.VYCHOD));
		assertFalse("Postava se chce presunout mimo mapu", p.jdi(Smer.JIH));
		assertFalse("Postava se chce presunout mimo mapu", p.jdi(Smer.ZAPAD));
		p.vykresli(gui);
		assertTrue("Postava se spatne vykreslila", gui.zapisCalls(10, 100)=='@');

	}

	/**
	 * Testuje metodu jeDoma
	 * - test kdyz jeste nebyla doma
	 * - test kdyz je doma
	 * - test kdyz odejde z domova
	 */
	@Test
	public void jeDoma() {
		SvetMock svet = new SvetMock();
		svet.uzemiReturn=' ';
		
		Postava p = new Postava(svet, 1,1,2,2);
		
		assertFalse("Postava rika, ze je doma, ale pritom stoji jinde", p.jeDoma());
		
		p.jdi(Smer.VYCHOD);		
		assertFalse("Postava rika, ze je doma, ale pritom stoji jinde", p.jeDoma());
		
		p.jdi(Smer.JIH);		
		assertTrue("Postava rika, ze neni doma, ale pritom by mela byt", p.jeDoma());

		p.jdi(Smer.ZAPAD);		
		assertFalse("Postava rika, ze je doma, ale pritom stoji jinde", p.jeDoma());
	}
}

