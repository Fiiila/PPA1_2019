import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.Scanner;

import org.junit.Test;

import ppa1.GUI;
import ppa1.Postava;
import ppa1.Ppa1u08;
import ppa1.Svet;

/**
 * Test hlavni tridy
 * @author pvanecek
 *
 */
public class Ppa1u08Test {

	/**
	 * Test metody spust
	 * - uspesne dorazeni do cile
	 * - neuspesne dorazeni do cile
	 */
	@Test
	public void spust() {
		Scanner scanner;
		GUI gui;
		Postava postava;
		Svet svet;
		String input;
		
		input = String.format(Locale.US,"6\n2\n");
		scanner = new Scanner(new ByteArrayInputStream(input.getBytes()));
		gui = new GUI(2,2,scanner);
		svet = new Svet(2,2,new char[] {' ', ' ', '#', ' '});
		postava = new Postava(svet, 0,0,1,1);		
		assertTrue(Ppa1u08.spust(gui, svet, postava));		

		input = String.format(Locale.US,"2\n6\n");
		scanner = new Scanner(new ByteArrayInputStream(input.getBytes()));
		gui = new GUI(2,2,scanner);
		svet = new Svet(2,2,new char[] {' ', ' ', '#', ' '});
		postava = new Postava(svet, 0,0,1,1);
		assertFalse(Ppa1u08.spust(gui, svet, postava));		
	}

}
