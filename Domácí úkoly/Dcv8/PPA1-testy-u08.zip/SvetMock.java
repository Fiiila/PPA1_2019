import ppa1.Svet;

public class SvetMock extends Svet {

	public char uzemiReturn;
	
	public SvetMock() {
		super(1, 1, new char[] {' '});
	}
	
	@Override
	public char uzemi(int x, int y) {
		return uzemiReturn;
	}

}
