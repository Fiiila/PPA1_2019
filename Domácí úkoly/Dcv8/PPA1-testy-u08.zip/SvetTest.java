import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Random;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ppa1.Svet;

/**
 * Test tridy Svet
 * @author pvanecek
 *
 */
public class SvetTest {
	
	char[] mapa;
	int sirka;
	int vyska;
	
	/**
	 * Generuje nahodnou mapu 
	 */
	void generujSvet() {
		Random r = new Random();
		sirka = r.nextInt(5)+3;
		vyska = sirka + r.nextInt(6)-2;
		mapa = new char[sirka*vyska];
		for(int i=0; i<mapa.length; i++) {
			mapa[i] = (char)(32 + 3*r.nextInt(2)); 
		}		
	}
	
	/**
	 * Testuje kresleni sveta
	 */
	@Test
	public void Svet_vykresli() {
		generujSvet();
		GUIMock g = new GUIMock();
		String funkce = String.format("Pro mapu o rozmerech %d, %d: ", sirka, vyska);
		
		try {
			Svet s = new Svet(sirka,vyska,mapa);
			s.vykresli(g);

			for(int i=0; i<mapa.length; i++) {
				int x = i%sirka;
				int y = i/sirka;
				assertTrue(funkce + "Svet se spatne vykreslil", g.zapisCalls(x,y)==mapa[i]);
			}
			assertTrue(funkce + "Svet zapisuje kam nema", g.zapisList.size()==0);
		}catch(Exception e) {
			assertTrue(funkce+"Neco se pokazilo. "+e.getMessage(), false);
		}
	}

	/**
	 * Testuje zjistovani uzemi na pozici x,y.
	 */
	@Test
	public void uzemi() {
		generujSvet();
		String funkce = String.format("Pro mapu o rozmerech %d, %d: ", sirka, vyska);

		try {
			Svet s = new Svet(sirka,vyska, mapa);

			// Test uzemi mimo mapu
			assertTrue(funkce+"Uzemi je chybne urcene.", s.uzemi(-1, 0)==0);
			assertTrue(funkce+"Uzemi je chybne urcene.", s.uzemi(sirka, vyska-1)==0);
			assertTrue(funkce+"Uzemi je chybne urcene.", s.uzemi(0, -1)==0);
			assertTrue(funkce+"Uzemi je chybne urcene.", s.uzemi(sirka-1, vyska)==0);

			for(int i=0; i<mapa.length; i++) {
				int x = i%sirka;
				int y = i/sirka;
				assertTrue("Uzemi je chybne urcene.", s.uzemi(x,y)==mapa[i]);
			}
		} catch (Exception e) {
			assertTrue(funkce+"Neco se pokazilo. "+e.getMessage(), false);
		}

	}



	private final ByteArrayOutputStream redir_out = new ByteArrayOutputStream();
	private PrintStream save_out;

	/**
	 * Presmerovani stdout do byte streamu
	 */
	@Before
	public void setRedirect() {
		save_out = System.out;
		System.setOut(new PrintStream(redir_out));
	}

	/**
	 * Obnoveni stdout
	 */
	@After
	public void resetRedirect() {
		System.setOut(save_out);
	}


}
